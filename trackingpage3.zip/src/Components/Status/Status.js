import React from 'react'

function Status() {
    return (
        <div style={{ marginLeft: '16px', width: 'auto', height: 'auto', }}><p style={{ fontFamily: 'Poppins', fontWeight: '600', fontSize: '16px', lineHeight: '24px', color: '#121114' }}>Tracking Status</p>
            <p style={{ fontFamily: 'Poppins', color: '#5F5A6B', fontWeight: '400', fontSize: '12px', lineHeight: '18px' }}>Quickly check your tracking status below or click on details see more info.</p></div>
    )
}
export default Status;