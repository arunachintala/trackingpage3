
import React from 'react';
import './Button.css';

const Button = () => {
    return (
        <button className="custom-button">
            Details &gt;
        </button>
    );
}

export default Button;
